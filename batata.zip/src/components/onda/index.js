import './index.css'

import Onda from '../../assets/onda.svg'

export default function App() {

    return(

        <div className="onda">

            <img alt='' src={Onda} />

        </div>

    )

}