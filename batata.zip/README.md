### RagnarokStore

Bom, eu iniciei o desenvolvimento desse site e durou aproximadamente 2 semanas. O site foi feito em ReactJS, com uma api disponivel para a criação de produtos, cupons, pagamentos e etc.

![Imagem do site](https://cdn.discordapp.com/attachments/803751189283078195/819334325928460309/unknown.png)

# Links

- Site: https://theragnarok.com.br